<?php 
include "config/db.php";
session_start();
if(isset($_POST['amt']) && isset($_POST['name']) && isset($_POST['city']) ){
    $payment_id = $_POST['payment_id'];
    $amount = $_POST['amt'];
    $name = $_POST['name'];
    $city = $_POST['city'];
    mysqli_query($conn,"INSERT INTO razorpay (name,amount,city) VALUES ('$name',$amount,'$city')");
    $_SESSION['OID'] = mysqli_insert_id($conn);
}
if(isset($_SESSION['OID'])&& isset($_POST['status']) && isset($_POST['payment_id'])){
    $payment_id = $_POST['payment_id'];
    if($_POST['status'] == 'success')
    mysqli_query($conn,"UPDATE razorpay SET payment_status = 'complete', payment_id = '$payment_id' where id = ".$_SESSION['OID']."");
    else
    mysqli_query($conn,"UPDATE razorpay SET payment_status = 'failed', payment_id = '$payment_id' where id = ".$_SESSION['OID']."");
}


?>