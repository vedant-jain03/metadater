<?php 
    $conn = mysqli_connect("localhost","root","","payment_gateway_integration");
?>