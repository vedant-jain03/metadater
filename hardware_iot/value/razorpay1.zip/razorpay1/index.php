<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Checkout</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-8">
                <div class="card">
                    <div class="card-body">
                        <form>
                            <div class="mb-3">
                                <label class="form-label">Name</label>
                                <input type="type" id="name" name="name" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">City</label>
                                <input type="text" id="city" name="city" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Amount</label>
                                <input type="text" id="amount" name="amount" class="form-control">
                            </div>
                            <input type="button" name="pay" value="Pay Now" class="btn btn-primary" onclick="pay_now()" />
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script>
        function pay_now() {
            var name = $("#name").val();
            var city = $('#city').val();
            var amount = $("#amount").val();
            $.ajax({
                type: "post",
                url: "payment_process.php",
                data: "amt=" + amount + "&name=" + name + "&city=" + city,
                success: function(result) {
                    var options = {
                        "key": "rzp_test_RMOoPH7LrWdI0I", // Enter the Key ID generated from the Dashboard
                        "amount": amount * 100, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
                        "currency": "INR",
                        "name": "The Metadaters",
                        "description": "Test Transaction",
                        // "image": "https://example.com/your_logo",
                        // "order_id": "order_9A33XWu170gUtm", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
                        "handler": function(response) {
                            console.log(response);
                            $.ajax({
                                type: "post",
                                url: "payment_process.php",
                                data: "payment_id=" + response.razorpay_payment_id+"&status=success",
                                success: function(result) {
                                    window.location.href="thankyou.php?status=payment+success";
                                }
                            });
                        },
                        "prefill": {
                            "name": name,
                            "email": "chaitanyarai19@gmail.com",
                            "contact": "8435407793"
                        },
                        "notes": {
                            "address": "Razorpay Corporate Office"
                        },
                        "theme": {
                            "color": "#3399cc"
                        }
                    };
                    var rzp1 = new Razorpay(options);
                    rzp1.on('payment.failed', function (response){
                        $.ajax({
                                type: "post",
                                url: "payment_process.php",
                                data: "payment_id=" +response.error.metadata.payment_id+"&status=failed",
                                success: function(result) {
                                    window.location.href="thankyou.php?status=payment+failed";
                                }
                            });
                            console.log(response);
                            // alert(response.error.code);
                            // alert(response.error.description);
                            // alert(response.error.source);
                            // alert(response.error.step);
                            // alert(response.error.reason);
                            // alert(response.error.metadata.order_id);
                            // alert(response.error.metadata.payment_id);
                    });
                    rzp1.open();
                    // document.getElementById('rzp-button1').onclick = function(e) {
                    //     e.preventDefault();
                    // }
                }
            });

        }
    </script>
</body>

</html>
